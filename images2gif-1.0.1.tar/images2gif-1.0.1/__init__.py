from images2gif import readGif as readGif
from images2gif import writeGif as writeGif
